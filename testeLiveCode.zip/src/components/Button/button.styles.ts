import styled from 'styled-components';

export const StyledButton = styled.button`
    background-color: #03fc84;
    border-radius: 4px;
    padding: 12px 24px;
`