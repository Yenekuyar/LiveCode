import React from 'react'
import { StyledImage } from './image.styles';

interface IImage {
  imageUrl: string
}

export default function Image(props: IImage) {
  return (
    <StyledImage src={props.imageUrl}/>
  )
}
