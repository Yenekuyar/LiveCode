import styled from 'styled-components';

export const StyledImage = styled.img`
    border: 2px solid black;
    width: 200px;
`