import styled from 'styled-components';

export const StyledContainer = styled.div`
    display: flex;
    justify-content: space-around;
    width: 100%;
    align-items: center;
    border: 2px solid #000;
    border-radius: 4px;
    padding: 12px;
    margin-top: 8px;
`