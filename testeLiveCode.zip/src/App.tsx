import './App.css';

function App() {
  return (
    <div>Teste</div>
  );
}

export default App;
