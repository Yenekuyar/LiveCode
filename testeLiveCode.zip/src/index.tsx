import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import SelectedProduct from './pages/SelectedProduct/selectedProduct.view';
import ProductPage from './pages/Product/product.view';
import { Route, createBrowserRouter, createRoutesFromElements, RouterProvider } from 'react-router-dom'

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path="/" element={<ProductPage/>}>
      <Route path=":id" element={<SelectedProduct/>}/>
    </Route>
  )
);

root.render(
  <React.StrictMode>
    <RouterProvider router={router}/>
  </React.StrictMode>
);

