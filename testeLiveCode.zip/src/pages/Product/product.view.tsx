import React from "react";
import Image from "../../components/Image/image.view";
import { productList } from "../../productList";
import { StyledContainer } from "../../components/Container/container.styles";
import { StyledLabel } from "../../components/Label/label.styles";
import { StyledText } from "../../components/Text/text.styles";
import { StyledButton } from "../../components/Button/button.styles";
import { useNavigate } from "react-router-dom";

export default function ProductPage() {
  const navigate = useNavigate();

  return (
    <>
      {productList.map((product) => {
        return (
          <StyledContainer>
            <StyledContainer>
              <Image imageUrl={product.PictureURL} />
              <StyledLabel>{product.Name}</StyledLabel>
              <StyledText>$ {product.Price}</StyledText>
              <StyledButton
                onClick={() => {
                  navigate(product.ProductID);
                }}
              >
                View Product
              </StyledButton>
            </StyledContainer>
          </StyledContainer>
        );
      })}
    </>
  );
}
