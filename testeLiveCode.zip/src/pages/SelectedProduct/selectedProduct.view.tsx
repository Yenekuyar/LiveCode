import React from 'react'

export default function SelectedProduct() {
  return (
    <div>SelectedProduct</div>
  )
}
